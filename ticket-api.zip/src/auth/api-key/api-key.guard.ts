import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class ApiKeyGuard implements CanActivate {
  constructor(private readonly prisma: PrismaService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    // Mengambil API Key dari header 'x-api-key'
    const apiKey = request.headers['x-api-key'];

    if (!apiKey) {
      throw new UnauthorizedException('API Key tidak ditemukan di header permintaan');
    }

    // Mencari organisasi di database berdasarkan API Key
    const organization = await this.prisma.organization.findUnique({
      where: { api_key: apiKey },
    });

    if (!organization) {
      throw new UnauthorizedException('API Key tidak valid');
    }

    // Menyisipkan data organisasi ke dalam object request agar bisa dibaca oleh Controller
    request.organization = organization;
    
    return true;
  }
}