import { Injectable, Logger } from '@nestjs/common';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class AiService {
  private readonly logger = new Logger(AiService.name);
  private genAI: GoogleGenerativeAI | null = null;

  constructor(private configService: ConfigService) {
    const apiKey = this.configService.get<string>('GEMINI_API_KEY');
    if (apiKey) {
      this.genAI = new GoogleGenerativeAI(apiKey);
    }
  }

  async analyzeTicket(subject: string, message: string) {
    // KEMBALIKAN KE NULL SESUAI SPESIFIKASI DOKUMEN
    const fallbackResult = { category: null, suggested_reply: null };

    if (!this.genAI) {
      this.logger.warn('GEMINI_API_KEY tidak ditemukan. Melewati proses AI.');
      return fallbackResult;
    }

    try {
      const model = this.genAI.getGenerativeModel({ model: 'gemini-3.8-flash' });

      const prompt = `
        Anda adalah asisten AI untuk layanan pelanggan.
        Analisis tiket berikut:
        Subjek: "${subject}"
        Pesan: "${message}"

        Tugas Anda:
        1. Klasifikasikan kategori tiket secara ketat ke salah satu dari: "billing", "technical", atau "general".
        2. Buat draf balasan singkat untuk membantu agen (suggested_reply) dalam bahasa yang sama dengan pesan pelanggan.

        PENTING: Jawab HANYA menggunakan format JSON murni tanpa tambahan teks apa pun, tanpa markdown (jangan gunakan \`\`\`json). Format:
        {
          "category": "...",
          "suggested_reply": "..."
        }
      `;

      const result = await model.generateContent(prompt);
      const responseText = result.response.text();

      const cleanJsonText = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
      const parsedData = JSON.parse(cleanJsonText);

      const validCategories = ['billing', 'technical', 'general'];
      const finalCategory = validCategories.includes(parsedData.category) 
        ? parsedData.category 
        : 'general';

      return {
        category: finalCategory,
        suggested_reply: parsedData.suggested_reply || null,
      };

    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : String(error);
      this.logger.error(`Gagal memanggil AI: ${message}`);
      return fallbackResult; 
    }
  }
}