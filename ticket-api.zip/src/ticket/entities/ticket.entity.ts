export class Ticket {}
